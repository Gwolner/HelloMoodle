<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/*
 * @package   hello_moodle
 * @copyright 2019 Guilherme Wolner
 */

print('
	<script>

		let head = document.getElementsByTagName("HEAD");
		console.log(head)
		let meta = document.createElement("META");
		meta.setAttribute("name", "viewport")
		meta.setAttribute("content", "width=device-width, initial-scale=1")

		let link = document.createElement("LINK");
		link.setAttribute("rel", "stylesheet")
		link.setAttribute("href", "https://www.w3schools.com/w3css/4/w3.css")

		head[0].appendChild(meta)
		head[0].appendChild(link)

		var recognizer;

		// Testa se o navegador suporta a API
		const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition || null;

		//Caso não suporte a API, imprime a mensagem no console.log            
		if (SpeechRecognition === null) {
			console.log("Plugin de voz não suportado neste navegador!");
		} else {
			recognizer = new SpeechRecognition(); //Instancia objeto de reconhecimento de voz 
			recognizer.continuous = true; //Não para de ouvir mesmo que tenha pausas no usuário
			recognizer.lang = navigator.language || navigator.userLanguage || "pt-BR"; // Define preferencia de idioma

			//Aciona o contexto principal
			contextHome();

			//CONTROLE DE AUDIÇÃO: Inicia e a cada 9,5 segundos reinicia.
			recognizer.start();
			setInterval(function () { recognizer.start(); }, 9500);

		}

		//Fecha a janela, desde que não haja outras abas abertas
		function sair() {
			window.close();
		}

		//Volta para a página anteriormente exibida
		function voltar() {
			window.history.back();
		}

		//Avança para a página seguinte (se houver)
		function avancar() {
			window.history.forward();
		}

		//Faz a barra de rolagem descer 100 pixels
		function descer() {
			window.scrollBy(0, 100)
		}

		//Faz a barra de rolagem subir 100 pixels
		function subir() {
			window.scrollBy(0, -100)
		}

		//Faz a barra de rolagem seguir direto para o topo da página
		function topo() {
			window.scrollTo(0, 0)
		}

		function contextHome() {
			recognizer.onresult = function (event) {

				//FOR percorre cada palavra dita a fim de analisar se há uma proxima ou se é a ultima
				for (var i = event.resultIndex; i < event.results.length; i++) {

					//Se for a ultima palavra dita, entra aqui
					if (event.results[i].isFinal) {

						//Pega a String contendo o que é dito pelo usuário e analisa nos IFs abaixo
						var pegaRetorno = (event.results[i][0].transcript.trim()).toUpperCase();

						//OPCIONAL PRA TESTES: Exibe no HTML a String contendo o que se é entendido pela API após fala do usuário e sua taxa de precisão no acerto do entendimento
						// elementoHTML.textContent = pegaRetorno + " (Taxa de acerto [0/1] : " + event.results[i][0].confidence + ")";

						if (pegaRetorno == "CLICK" || pegaRetorno == "LIKE") {
							//Contexto de Click
							contextClick();
						}

						if (pegaRetorno == "RETORNAR") {
							voltar();
						}

						if (pegaRetorno == "AVANÇAR") {
							avancar();
						}

						if (pegaRetorno == "SUBIR" || pegaRetorno == "SUBA") {
							subir();
						}

						if (pegaRetorno == "DESCER" || pegaRetorno == "DESÇA" || pegaRetorno == "DESSA") {
							descer();
						}

						if (pegaRetorno == "TOPO" || pegaRetorno == "VÁ PARA O TOPO" || pegaRetorno == "VÁ PARA O TOPO"
							|| pegaRetorno == "ROLE PARA O TOPO") {
							topo();
						}

						if (pegaRetorno == "RECARREGUE" || pegaRetorno == "RECARREGUE A PÁGINA" || pegaRetorno == "RECARREGUE A PAGINA"
							|| pegaRetorno == "RECARREGAR" || pegaRetorno == "RECARREGAR PÁGINA" || pegaRetorno == "RECARREGAR PAGINA") {
							document.location.reload(true);
						}

						if (pegaRetorno == "SAIR") {
							sair();
						}
					}
				}
			}
		}

		//Seleciona os elementos interativos da tela
		function selectAll() {

			//Define os elementos da tela que qeuro selecionar 
			let allItems = document.querySelectorAll("input, a, button, link")
			let index = 0

			//Para cada item selecionado realiza uma análise 
			allItems.forEach((item) => {
				index++

				if (item.type == "radio" || item.type == "checkbox") {

					//Cria uma Badge para o item
					let tempSpan = document.createElement("span")
					tempSpan.setAttribute("class", "w3-badge")
					tempSpan.innerText = index

					//Associa a Badge ao item e o evidencia com uma borda colorida destacada
					item.parentNode.insertBefore(tempSpan, item.nextSibling);
					item.setAttribute("style", "border:2px solid orange")
					item.setAttribute("id", index)

				} else if (item.tagName == "BUTTON" || item.type == "button") {

					//Este IF poderia ter sido incluido no anterior, mas para separar o que os tipos Buttons, foi criado este em específico!!

					//Cria uma Badge para o item
					let tempSpan = document.createElement("span")
					tempSpan.setAttribute("class", "w3-badge")
					tempSpan.innerText = index

					//Associa a Badge ao item e o evidencia com uma borda colorida destacada
					item.parentNode.insertBefore(tempSpan, item.nextSibling);
					item.setAttribute("style", "border:2px solid orange")
					item.setAttribute("id", index)

				} else if (item.type == "submit") {

					//Criar Div Auxiliar
					let tempDiv = document.createElement("div")

					//Criar Badge com Index
					let tempSpan = document.createElement("span")
					tempSpan.setAttribute("class", "w3-badge")
					tempSpan.innerText = index

					//Obtendo a Div Pai do botão
					let tempPai = item.parentNode;
					tempPai.setAttribute("class", "temias") //QUEBRANDO CLASS DO PAI!!!
					tempDiv.appendChild(item) //Atribuindo item a Div Auxiliar

					//Posiciona a Badge ao item e o evidencia com uma borda colorida destacada
					item.parentNode.insertBefore(tempSpan, item.nextSibling)
					item.setAttribute("style", "border:2px solid orange")
					item.setAttribute("id", index)

					tempPai.appendChild(tempDiv); //Adiciona Div Auxiliar na Div Pai

				} else {

					//Para demais elementos da tela, cria-se um label
					let tempLabel = document.createElement("label")
					tempLabel.setAttribute("style", "background-color:orange; padding:.66rem")
					tempLabel.innerText = index

					//Associa o label ao item
					item.appendChild(tempLabel)
					item.setAttribute("style", "border:2px solid orange")
					item.setAttribute("id", index)
				}
			})
		};

		function contextClick() {

			selectAll();
			recognizer.onresult = function (event) {

				var pegaRetorno;
				for (var i = event.resultIndex; i < event.results.length; i++) {
					if (event.results[i].isFinal) {

						//Pega a String contendo o que é dito pelo usuário e analisa nos IFs abaixo
						pegaRetorno = (event.results[i][0].transcript.trim()).toUpperCase();

						//Armazena o que é dito no Local Storage
						localStorage.setItem("pegaRetorno", pegaRetorno)

						/*
						Análise de voz deve ser inseridos antes da ação de click(), pois irá gerar
						erro ao se efetuar click em objeto null (Ex: objeto de id "voltar" seria executado)
						*/
						if (pegaRetorno == "VOLTAR") {
							document.location.reload(true);
						}

						if (pegaRetorno == "SUBIR" || pegaRetorno == "SUBA") {
							subir();
						}

						if (pegaRetorno == "DESCER" || pegaRetorno == "DESÇA" || pegaRetorno == "DESSA") {
							descer();
						}

						if (pegaRetorno == "TOPO" || pegaRetorno == "VÁ PARA O TOPO" || pegaRetorno == "VÁ PARA O TOPO"
							|| pegaRetorno == "ROLE PARA O TOPO") {
							topo();
						}

						if (pegaRetorno == "RECARREGUE" || pegaRetorno == "RECARREGUE A PÁGINA" || pegaRetorno == "RECARREGUE A PAGINA"
							|| pegaRetorno == "RECARREGAR" || pegaRetorno == "RECARREGAR PÁGINA" || pegaRetorno == "RECARREGAR PAGINA") {
							document.location.reload(true);
						}

						//OBS: são estas ações que tratam dos numeros mencionados pelo usuario. Ex.: Usuário fala "5". 

						//Recupera o que está no Local Storage e usa o seu id, obtendo-se assim, seu respectivo item
						let itemSelected = document.getElementById(localStorage.getItem("pegaRetorno"));

						//Realiza ação de click sobre o item selecionado
						itemSelected.click();
					}
				}
			}
		};
	</script>
'); 
 
// It must be included from a Moodle page
defined('MOODLE_INTERNAL') || die();

// specify the plugin version, usually specified by YYYYMMDD followed by 00
$plugin->version   = 2019122700;

// The version of moodle that's at least required for this plugin to be functional
$plugin->requires  = 2011102700;

// The name of the plugin
$plugin->component = 'local_hello_moodle';

// This means that the plugin won't recieve major updates and is ready for the production
$plugin->maturity  = MATURITY_STABLE;

// The realease version of your plugin, in this case this is the first release
$plugin->release   = '1.0';